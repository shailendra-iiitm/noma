@echo off
REM Compilation script for restructured NOMA GNN thesis
REM This script compiles the thesis with proper bibliography generation

echo ========================================
echo NOMA GNN Thesis Compilation Script
echo ========================================
echo.

echo [1/5] First pdflatex pass (generating aux files)...
pdflatex -interaction=nonstopmode main.tex
if %errorlevel% neq 0 (
    echo ERROR: First pdflatex pass failed!
    pause
    exit /b 1
)
echo.

echo [2/5] Running BibTeX (processing bibliography)...
bibtex main
if %errorlevel% neq 0 (
    echo WARNING: BibTeX encountered errors. Continuing anyway...
)
echo.

echo [3/5] Second pdflatex pass (resolving citations)...
pdflatex -interaction=nonstopmode main.tex
if %errorlevel% neq 0 (
    echo ERROR: Second pdflatex pass failed!
    pause
    exit /b 1
)
echo.

echo [4/5] Third pdflatex pass (resolving cross-references)...
pdflatex -interaction=nonstopmode main.tex
if %errorlevel% neq 0 (
    echo ERROR: Third pdflatex pass failed!
    pause
    exit /b 1
)
echo.

echo [5/5] Cleaning up auxiliary files...
del main.aux main.log main.out main.toc main.lof main.lot main.bbl main.blg 2>nul
echo.

echo ========================================
echo Compilation SUCCESSFUL!
echo Output: main.pdf
echo ========================================
echo.

REM Check if PDF was created
if exist main.pdf (
    echo PDF file created successfully!
    echo File size:
    dir main.pdf | find "main.pdf"
    echo.
    echo Opening PDF...
    start main.pdf
) else (
    echo ERROR: PDF file was not created!
)

pause
